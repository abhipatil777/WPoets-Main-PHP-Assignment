1.) I spent approximatey 4 full days on this test to create this Webpage.
    I would try to make animations more smoother and better transitions to the Wbpage.I would also try to make it mre responsive accordin to dfferent devices.

2.) I would track down the perfomance issue in Code by making load times faster and removing unnecessary service calls or resources which are taking tie to load.
    I have tracked down perfomance issues in various compnents of Admin website or Angula apps that i ahave worked on. As a developer i take necesary precautions and follow the code standard to prevent this type of perfomance issues.

3.) {
	"name": "Jainil Mehta",
	"Occupation": "Softare Developer",
	"experience": "11 Months",
	"skils": [
		"PHP",
		"Angular",
		"Javascript",
		"Python",
		"Git",
		"SQL",
		"HTML",
		"CSS"
	],
	"education": {
		"degree": "Bachelor of Technology in Computer Science and Engineering",
		"university": "Charotar University of Science and Technology",
		"graduation": "April 2023"
	}
}